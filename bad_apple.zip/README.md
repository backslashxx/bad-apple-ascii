
somehow ksu and ap cant even handle 0.5 sleep / 2fps

magisk and mmrl will do 4fps on this

[Download](https://raw.githubusercontent.com/backslashxx/bad-apple-ascii/refs/heads/magisk-module/bad_apple.zip)
