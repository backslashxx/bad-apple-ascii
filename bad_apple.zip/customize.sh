chmod 755 ${MODPATH}/action.sh ${MODPATH}/badapple
